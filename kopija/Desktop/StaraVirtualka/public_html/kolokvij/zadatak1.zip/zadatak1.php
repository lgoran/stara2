<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zadatak 1</title>
</head>
<body>
    <form action="zadatak1_poslovi.php" method="post">
    Unesi projekt:<input type="text" name="projekt" id="projekt">
    <button type="submit">Submit</button>
    </form>
</body>
</html>