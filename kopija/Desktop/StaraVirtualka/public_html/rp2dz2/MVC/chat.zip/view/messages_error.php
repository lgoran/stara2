<?php require_once __DIR__ . '/_header.php'; ?>

<?php require_once __DIR__ . '/_footer.php'; ?>