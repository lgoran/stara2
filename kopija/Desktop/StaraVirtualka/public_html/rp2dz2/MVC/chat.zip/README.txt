Treba prilagoditi spajanje na bazu u app/database/db.class.php
