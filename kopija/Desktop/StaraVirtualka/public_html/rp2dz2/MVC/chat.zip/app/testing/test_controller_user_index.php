<?php 

require_once __DIR__ . '/../../controller/usersController.php';

$controller = new UsersController();
$controller->index();

?>
